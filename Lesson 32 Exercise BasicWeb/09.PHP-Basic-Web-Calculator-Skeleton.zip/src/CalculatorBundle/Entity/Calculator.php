<?php
/**
 * Created by PhpStorm.
 * User: Marto
 * Date: 26/11/18
 * Time: 14:03
 */

namespace CalculatorBundle\Entity;

class Calculator
{
    //TODO Calculator class
    public function calculateResult()
    {
        //TODO Calculate result
    }
}